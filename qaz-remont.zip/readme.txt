npm install
gulp default